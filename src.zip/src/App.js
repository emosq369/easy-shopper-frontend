import React, { useEffect, useState } from 'react';
import AuthenticatonForm from './LoginForm.js'
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import AdminHome from './AdminHome.js';
import CustomerHome from './CustomerHome.js';
import Orders from'./Orders.js';
import Order from './Order.js';

import './App.css';

function App() {
  const [isAunthenticated, setIsAunthenticated] = useState(false);
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    const storedRole = sessionStorage.getItem('role');
    const StoredUserId = sessionStorage.getItem('userId');
    console.log('UserId', sessionStorage.getItem('userId'));
    if(StoredUserId && storedRole) {
      setIsAunthenticated(true);
      setUserRole(storedRole);
    }
  }, []);

  function handleLoginSucces(role, userId) {
    setIsAunthenticated(true);
    setUserRole(role);
    sessionStorage.setItem('userId', userId)
    sessionStorage.setItem('role', role)
  }

  function handleLogout() {
    setIsAunthenticated(false);
    setUserRole('');
    sessionStorage.removeItem('role');
    sessionStorage.removeItem('userId');
  }

  return (
    <Router>
      <Routes>
        {/* Log in route */}
        <Route path='/' element={isAunthenticated ? (<Navigate to={userRole === 'manager' ? '/admin' : '/home'} />) : 
          (<AuthenticatonForm onLoginSuccess={handleLoginSucces}/>)}
        />
        {/* Manager home */}
        <Route path="/admin" element={isAunthenticated && userRole === 'manager' ? (<AdminHome onLogout={handleLogout}/>) : 
          (<Navigate to='/'/>)}
        />
        {/* Customer home */}
        <Route path="/home" element={isAunthenticated && userRole === 'customer' ? (<CustomerHome onLogout={handleLogout}/>) : 
        (<Navigate to='/'/>)}/>
        {/* Orders page */}
        <Route path="/orders" element={isAunthenticated && userRole === 'customer' ? (<Orders/>) : (<Navigate to='/'/>)}/>
        {/* Order page */}
        <Route path="/order/:orderId" element={isAunthenticated && userRole === 'customer' ? (<Order />) : (<Navigate to='/'/>)} />
      </Routes>
    </Router>
  );
}

export default App;
