import React, { useState, useEffect } from 'react';
import Product from './Product.js';
import { Link } from 'react-router-dom';

function CustomerHome({ onLogout }) {
  const [products, setProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetch('http://localhost:5001/products')
      .then(response => response.json())
      .then(data => {setProducts(data)})
      .catch(err => console.error('Error fetching products', err))
  }, []);

  const addToCart = (productId) => {
    console.log(`Add product ${productId} to cart`);
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(productId);
    localStorage.setItem('cart', JSON.stringify(cart));
  };

  const filteredProducts = products.filter(product =>
    product.product_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <h1>Product Catalog</h1>

      {/* Navigation Links */}
      <div className="navigation-links">
        <Link to="/cart">Cart</Link> | 
        <Link to="/orders">Orders</Link>
        <button onClick={onLogout}>Logout</button>
      </div>

      {/* Search Bar */}
      <input
        type="text"
        placeholder="Search products..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      {/* Product List */}
      <div className="product-grid">
        {filteredProducts.map(product => (
            <Product key={product.product_id} product={product}>
              <button onClick={() => console.log(`Add ${product.product_name} to cart`)}>
                Add to Cart
              </button>
            </Product>
        ))}
      </div>
    </div>
  );
}

export default CustomerHome;
